# Expense Tracker

A clean React expense tracking app.

## Getting Started

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

## Features
- Add expenses with description, amount, and category
- Category summary cards with spending breakdown
- Running total display
- Delete individual expenses
- Responsive design

## Categories
Food, Transport, Shopping, Bills, Health, Fun, Other

## Build for Production
```bash
npm run build
```
