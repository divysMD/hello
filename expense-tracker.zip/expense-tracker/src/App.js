import { useState } from "react";
import "./App.css";

const CAT_META = {
  Food:      { emoji: "🍔", color: "#1D9E75", bg: "#E1F5EE" },
  Transport: { emoji: "🚌", color: "#378ADD", bg: "#E6F1FB" },
  Shopping:  { emoji: "🛍", color: "#D4537E", bg: "#FBEAF0" },
  Bills:     { emoji: "💡", color: "#E24B4A", bg: "#FCEBEB" },
  Health:    { emoji: "💊", color: "#7F77DD", bg: "#EEEDFE" },
  Fun:       { emoji: "🎉", color: "#EF9F27", bg: "#FAEEDA" },
  Other:     { emoji: "📦", color: "#888780", bg: "#F1EFE8" },
};

function App() {
  const [expenses, setExpenses] = useState([]);
  const [desc, setDesc] = useState("");
  const [amt, setAmt] = useState("");
  const [cat, setCat] = useState("Food");

  const total = expenses.reduce((s, e) => s + e.amt, 0);

  const catTotals = expenses.reduce((acc, e) => {
    acc[e.cat] = (acc[e.cat] || 0) + e.amt;
    return acc;
  }, {});

  const addExpense = () => {
    const amount = parseFloat(amt);
    if (!desc.trim() || isNaN(amount) || amount <= 0) return;
    setExpenses([
      {
        id: Date.now(),
        desc: desc.trim(),
        amt: amount,
        cat,
        date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      },
      ...expenses,
    ]);
    setDesc("");
    setAmt("");
  };

  const deleteExpense = (id) => setExpenses(expenses.filter((e) => e.id !== id));

  return (
    <div className="container">
      <header className="header">
        <div>
          <h1>Expense Tracker</h1>
          <p className="subtitle">Track where your money goes</p>
        </div>
        <div className="total-box">
          <span className="total-label">Total spent</span>
          <span className="total-amount">${total.toFixed(2)}</span>
        </div>
      </header>

      {Object.keys(catTotals).length > 0 && (
        <div className="cat-grid">
          {Object.entries(catTotals)
            .sort((a, b) => b[1] - a[1])
            .map(([c, v]) => (
              <div key={c} className="cat-card" style={{ background: CAT_META[c].bg, borderColor: CAT_META[c].color + "44" }}>
                <p className="cat-name" style={{ color: CAT_META[c].color }}>{c}</p>
                <p className="cat-amt">${v.toFixed(2)}</p>
                <div className="bar-bg">
                  <div className="bar-fill" style={{ width: `${Math.round((v / total) * 100)}%`, background: CAT_META[c].color }} />
                </div>
              </div>
            ))}
        </div>
      )}

      <div className="add-card">
        <p className="section-label">Add expense</p>
        <div className="add-form">
          <input
            type="text" placeholder="Description" value={desc}
            onChange={(e) => setDesc(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && document.getElementById("amt").focus()}
          />
          <input
            id="amt" type="number" placeholder="Amount" min="0" step="0.01" value={amt}
            onChange={(e) => setAmt(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addExpense()}
          />
          <select value={cat} onChange={(e) => setCat(e.target.value)}>
            {Object.entries(CAT_META).map(([c, m]) => (
              <option key={c} value={c}>{m.emoji} {c}</option>
            ))}
          </select>
          <button onClick={addExpense}>+ Add</button>
        </div>
      </div>

      {expenses.length === 0 ? (
        <p className="empty">No expenses yet. Add one above!</p>
      ) : (
        <div className="expense-list">
          <p className="section-label">Recent expenses</p>
          {expenses.map((e) => (
            <div key={e.id} className="expense-row">
              <div className="expense-icon" style={{ background: CAT_META[e.cat].bg }}>
                {CAT_META[e.cat].emoji}
              </div>
              <div className="expense-info">
                <p className="expense-desc">{e.desc}</p>
                <p className="expense-meta">{e.cat} · {e.date}</p>
              </div>
              <span className="expense-amt">${e.amt.toFixed(2)}</span>
              <button className="delete-btn" onClick={() => deleteExpense(e.id)} aria-label="Delete">🗑</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;
